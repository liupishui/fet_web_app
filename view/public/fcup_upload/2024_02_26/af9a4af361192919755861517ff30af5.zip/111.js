    function runTask(taskArr,processAsyncFun,maxRun){
        return new Promise(async function(resolve,reject){
            let taskArrOrg = JSON.parse(JSON.stringify(taskArr));
            taskArr = taskArr.reverse();
            let count = 0;
            let runTaskEach = async function(){
                count++;
                if(count===taskArrOrg.length){
                    resolve('over');
                }else{
                    try{
                        let data = await processAsyncFun(taskCurr,taskArrOrg.length-taskArr.length-1,taskArrOrg);
                        console.log('2222',data,taskArr.length);
                    } catch(e) {
                        console.log(333,e);
                    } finally {
                        runTaskEach();
                    }
                }
            }
            for(let i=0;i<maxRun;i++){
                runTaskEach(taskArr);
            }
        });
    }
    runTask(['https://www.sogou.com/web/index/images/weather/multicolor/qing.png','https://img02.sogoucdn.com/app/a/200797/e742a846-8920-4c1b-958b-cbdea5d0dce7','https://www.sogou.com/web/index/images/weather/multicolor/qing.png','https://img02.sogoucdn.com/app/a/200797/e742a846-8920-4c1b-958b-cbdea5d0dce7','https://www.sogou.com/web/index/images/weather/multicolor/qing.png','https://img02.sogoucdn.com/app/a/200797/e742a846-8920-4c1b-958b-cbdea5d0dce7','https://www.sogou.com/web/index/images/weather/multicolor/qing.png','https://img02.sogoucdn.com/app/a/200797/e742a846-8920-4c1b-958b-cbdea5d0dce7','https://www.sogou.com/web/index/images/weather/multicolor/qing.png','https://img02.sogoucdn.com/app/a/200797/e742a846-8920-4c1b-958b-cbdea5d0dce7','https://www.sogou.com/web/index/images/weather/multicolor/qing.png','https://img02.sogoucdn.com/app/a/200797/e742a846-8920-4c1b-958b-cbdea5d0dce7',], function(taskCurr,index,taskAll){
        return new Promise(async (resolve,reject)=>{
            let data = await fetch(taskCurr);
            resolve(data);
        });
    },3).then(data=>console.log(data)).catch(e=>{console.log(e)});