$(function () {
    $(".data-index").marquee({direction:'left'});
    var chanage_recharge_method = function(method){
        $(".form-group-recharge_method .selected_metchod").find('.icon')[0].className="icon icon-recharge_method_"+method;
        switch(method){
            case 'btc':{
                $(".form-group-recharge_method .selected_metchod").find('.name').text('BTC')
            }
            break;
            case 'eth':{
                $(".form-group-recharge_method .selected_metchod").find('.name').text('ETH')
            }
            break;
            case 'usdt':{
                $(".form-group-recharge_method .selected_metchod").find('.name').text('USDT')
            }
            break;
            case 'credit_card':{
                $(".form-group-recharge_method .selected_metchod").find('.name').text('Credit Card')
            }
            break;
            case 'manual_recharge':{
                $(".form-group-recharge_method .selected_metchod").find('.name').text('Manual Recharge')
            }
            break;
        }
    }
    $(".form-group-recharge_method .methods-group .item").click(function(){
        $(this).siblings().removeClass('curr').end().addClass('curr');
        chanage_recharge_method($(this).attr('data-method'));
    });
    $(".selectbox-hd").click(function(){
        $(this).next().slideToggle(10);
    });
    $(".selectbox-bd .item").click(function(){
        $(this).parent().prev().html($(this).html());
        $(this).parent().slideUp(0);
    });
    $(document).delegate('*','click',function(e){
        if($(".selectbox").find($(e.target)).length==0){
            $(".selectbox").find('.selectbox-bd').slideUp(0);
        }
    });

    $(".btn-revise").click(function(e){
        e.preventDefault();
        $(".layer-modify").fadeIn(200);
    });
    $(".layer-modify").click(function(e){
        if(e.target.className=='layer-modify'){
           $(".layer-modify").fadeOut(0);
        };
    })
    $(".layer-modify .btn-close").click(function(){
        $(".layer-modify").fadeOut(0);
    });
})


