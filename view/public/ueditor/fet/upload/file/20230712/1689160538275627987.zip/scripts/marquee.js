(function($){
    jQuery.fn.extend({
        marquee:function(option){
            var defaultOption = {
                direction:'left',
                speed:80 // speed 是指每秒移动多少像素
            }
            $.extend(true,defaultOption,option);
            if($(this).children().length==0){
                return;
            }
            var domOrg = $(this).children().eq(0);
            if(defaultOption.direction === 'left' && $(this).width() >= domOrg.outerWidth()){
                return;
            }
            if(defaultOption.direction === 'top' && $(this).height() >= domOrg.outerHeight()){
                return;
            }
            $(this).append(domOrg.clone(true));
            var timeStart = new Date().getTime();
            var timeTotalW = domOrg.outerWidth()/defaultOption.speed*1000;
            var timeTotalH = domOrg.outerHeight()/defaultOption.speed*1000;
            var linear = function(t, b, c, d) { return c*t/d + b; };
            var that = $(this);
            that['marqueeFn'] = function () {
                    if(that['marqueeFn']['stop']){
                   that['marqueeFn']['timeProcess'] = that['marqueeFn']['timeCurr'];
                }else{
                    if(that['marqueeFn']['loop'] == false){
                        that['marqueeFn']['loop'] = true;
                        timeStart = new Date().getTime() - that['marqueeFn']['timeProcess'];
                    }
                    that['marqueeFn']['timeCurr'] = new Date().getTime()-timeStart;
                    if(defaultOption.direction === 'left'){
                        if(that['marqueeFn']['timeCurr']>=timeTotalW){
                            timeStart = new Date().getTime();
                            that['marqueeFn']['timeCurr'] = 0;
                        }
                        that.scrollLeft(linear(that['marqueeFn']['timeCurr'],0,domOrg.outerWidth(),timeTotalW));
                    }
                    if(defaultOption.direction === 'top'){
                        if(that['marqueeFn']['timeCurr']>=timeTotalH){
                            timeStart = new Date().getTime();
                            that['marqueeFn']['timeCurr'] = 0;
                        }
                        that.scrollTop(linear(that['marqueeFn']['timeCurr'],0,domOrg.outerHeight(),timeTotalH));
                    }
                }
            };
            that['timmer'] = setInterval(function(){that['marqueeFn'].call(that)}, 1);
            that.mouseenter(function(){
                 that['marqueeFn']['stop'] = true; that['marqueeFn']();clearInterval(that['timmer']);
             });
            that.mouseleave(function(){
                that['marqueeFn']['stop'] = false; that['marqueeFn']['loop'] = false; that['timmer'] = setInterval(that['marqueeFn'], 1);
            })
            $.extend(true,that,{
                stopMarquee:function(){
                    that['marqueeFn']['stop'] = true; that['marqueeFn']();clearInterval(that['timmer'])
                },
                startMarquee:function(){
                that['marqueeFn']['stop'] = false; that['marqueeFn']['loop'] = false; that['timmer'] = setInterval(that['marqueeFn'], 1);
                }
            })
            return that;
        }
    });
})(jQuery)
